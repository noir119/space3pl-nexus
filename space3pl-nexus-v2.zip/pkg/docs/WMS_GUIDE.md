# WMS Mobile App Guide — Space3PL

Complete guide for warehouse staff using the WMS app at `/wms`.

---

## Signing In

**Method 1 — Email + Password**
Use the same credentials as the Admin Panel.

**Method 2 — Employee ID + PIN** (recommended for warehouse staff)
- Employee ID: e.g. `EMP-042`
- PIN: 4–6 digit number (set by admin in User Management)

The PIN login works offline-first and is faster on a mobile device.

---

## Dashboard

After login you see:
- **My Picklists** — picklists assigned to you
- **Putaway Tasks** — items waiting to be put away
- **Open Inbounds** — POs expected today
- **Cycle Counts** — counts scheduled and assigned to you
- **My Tasks** — quick list of your pending work
- **Quick Actions** — tap any icon to jump straight to that function

---

## Picking

**Starting a pick:**
1. Tap **Pick** or **🛒 Picking** from the bottom navigation
2. You will see all picklists assigned to you
3. Tap a picklist → tap **🛒 Start Picking**
4. Items are shown sorted by bin location (optimal path)
5. Tap **Pick ✓** on each item as you collect it
6. Once all items are ticked, tap **✅ Complete Picking → Packing**

**Sorting by bin:** Tap the 📍 icon in the top right to re-sort items by bin location — this gives you the shortest walking path.

**Picking modes (set by supervisor):**
- **Single** — one order per picklist
- **Batch** — multiple orders combined into one pick run
- **Zone** — you are assigned a specific zone and pick all items in it

---

## Packing

1. Tap **Pack** from Quick Actions or the bottom navigation
2. Orders that have been fully picked appear here
3. Tap **📦 Pack This Order** on any order
4. In the sheet that opens:
   - Select box size (Small / Medium / Large)
   - Enter weight in kg
   - Toggle bubble wrap and fragile label if needed
   - Add any special instructions
5. Tap **✅ Confirm Packed → Print Label**
6. The packing record is saved to the database

---

## Inbound Receiving

1. Tap **Receive** or **📥** from Quick Actions
2. Today's expected inbound POs are listed
3. Optionally scan or type the PO number in the scan box to jump directly to a receipt
4. Tap a receipt to open it
5. For each line:
   - Adjust the received quantity using the +/− stepper
   - Change condition if needed (Good / Damaged / Wrong Item)
6. Tap **Partial Save** if you are still receiving, or **✅ Complete** when done
7. Putaway tasks are automatically created for all received items

---

## Putaway

1. Tap **Putaway** or **🗺️** from Quick Actions
2. All items waiting for putaway are listed, sorted by zone
3. To find a specific item: scan its SKU barcode in the scan box
4. Tap **Put Away** on any item
5. A sheet shows the **Suggested Bin** location
6. Physically move the item to that bin in the warehouse
7. If you put it in a different bin, enter the actual bin code
8. Tap **✅ Put Away Complete** — inventory is updated automatically

---

## Cycle Count

1. Tap **Count** or **🔄** from the bottom navigation
2. Zones scheduled for counting today are highlighted with **"Due Today ⏰"**
3. Tap a zone → tap **🔄 Start Counting**
4. For each item shown:
   - The **System Qty** is what the database thinks is there
   - Use the +/− stepper to enter what you actually count
5. Tap **📊 Submit Count** when done
6. A variance report appears showing any differences
7. Variances are flagged to the supervisor for approval

---

## Stock Lookup

Use this to instantly check where any item is and how much stock there is.

1. Tap **Search** or **🔍** from the bottom navigation or Quick Actions
2. Type a **SKU**, **product name**, or **bin code**
3. Results show in real-time as you type
4. Each result card shows:
   - Bin location and zone
   - **On Hand** — total physical stock
   - **Reserved** — allocated to open orders
   - **Available** — on hand minus reserved (what can be picked)
   - Low stock warning if available ≤ reorder point

---

## Tips for Warehouse Use

- **Scanning:** The scan input fields accept input from a Bluetooth barcode scanner. Connect the scanner to your phone via Bluetooth — it will type into the focused input field automatically.

- **Keep screen on:** Enable "Stay awake" in your phone's developer options, or set screen timeout to maximum while working.

- **Offline:** The app requires internet to load. Once loaded, basic navigation works offline but data will not save until reconnected.

- **PIN login is fastest:** For quick daily login, use Employee ID + PIN instead of email + password.

---

*Space3PL WMS Mobile App Guide — v2.0 — 2026*
