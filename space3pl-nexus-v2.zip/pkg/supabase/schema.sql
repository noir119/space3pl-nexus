-- ============================================================
-- SPACE3PL NEXUS — COMPLETE SUPABASE SCHEMA
-- Version: 2.0.0
-- Project: eqmjdojaqzaakmbcsakc (Supabase EU West 2 / London)
-- ============================================================
-- HOW TO RUN:
--   1. Open your Supabase project → SQL Editor
--   2. Paste this entire file and click Run
--   3. Run once — all statements are idempotent (safe to re-run)
-- ============================================================

-- ── EXTENSIONS ──────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================
-- SECTION 1 — ENUMS
-- ============================================================
DO $$ BEGIN CREATE TYPE user_role AS ENUM (
  'super_admin','admin','manager','warehouse',
  'logistics','finance','picker','packer','receiver'
); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN CREATE TYPE order_status AS ENUM (
  'pending','processing','picked','packed',
  'dispatched','delivered','cancelled','returned'
); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN CREATE TYPE inbound_status AS ENUM (
  'draft','expected','receiving','received','putaway_pending','closed'
); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN CREATE TYPE picklist_method AS ENUM (
  'single','batch','zone'
); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN CREATE TYPE picklist_status AS ENUM (
  'pending','assigned','picking','complete','cancelled'
); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN CREATE TYPE putaway_status AS ENUM (
  'waiting','assigned','in_progress','complete'
); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN CREATE TYPE item_condition AS ENUM (
  'good','damaged','wrong_item','expired'
); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN CREATE TYPE cycle_count_status AS ENUM (
  'scheduled','in_progress','submitted','approved','rejected'
); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN CREATE TYPE movement_type AS ENUM (
  'inbound','outbound','transfer','adjustment','return','cycle_count'
); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN CREATE TYPE priority_level AS ENUM (
  'normal','urgent','vip'
); EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- ============================================================
-- SECTION 2 — CORE REFERENCE TABLES
-- ============================================================

-- 2.1 Profiles (linked to Supabase auth.users)
CREATE TABLE IF NOT EXISTS profiles (
  id               UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name        TEXT NOT NULL,
  employee_id      TEXT UNIQUE,
  role             user_role NOT NULL DEFAULT 'picker',
  email            TEXT,
  phone            TEXT,
  department       TEXT,
  shift            TEXT CHECK (shift IN ('morning','evening','night','flexible')),
  hire_date        DATE,
  pin              TEXT,                     -- WMS mobile app PIN (plain text for demo)
  is_active        BOOLEAN DEFAULT TRUE,
  avatar_url       TEXT,
  permissions      JSONB DEFAULT '{}'::jsonb,
  notes            TEXT,
  created_by       UUID REFERENCES profiles(id),
  last_login_at    TIMESTAMPTZ,
  created_at       TIMESTAMPTZ DEFAULT NOW(),
  updated_at       TIMESTAMPTZ DEFAULT NOW()
);
COMMENT ON COLUMN profiles.pin         IS '4–6 digit PIN for WMS mobile app login';
COMMENT ON COLUMN profiles.permissions IS 'Granular permission overrides per module';

-- 2.2 Warehouses
CREATE TABLE IF NOT EXISTS warehouses (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name       TEXT NOT NULL,
  address    TEXT,
  city       TEXT,
  country    TEXT DEFAULT 'OM',
  is_active  BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2.3 Zones
CREATE TABLE IF NOT EXISTS zones (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  warehouse_id UUID REFERENCES warehouses(id) ON DELETE CASCADE,
  code         TEXT NOT NULL,
  name         TEXT NOT NULL,
  category     TEXT,
  color        TEXT DEFAULT '#0ea5e9',
  total_bins   INT  DEFAULT 200,
  is_active    BOOLEAN DEFAULT TRUE,
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(warehouse_id, code)
);

-- 2.4 Bin Locations
CREATE TABLE IF NOT EXISTS bin_locations (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  zone_id     UUID REFERENCES zones(id) ON DELETE CASCADE,
  code        TEXT NOT NULL,              -- e.g. A-01-02 (Zone-Row-Bay)
  row_num     INT,
  bay_num     INT,
  level_num   INT,
  capacity    INT DEFAULT 100,
  current_qty INT DEFAULT 0,
  is_active   BOOLEAN DEFAULT TRUE,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(zone_id, code)
);

-- 2.5 Suppliers
CREATE TABLE IF NOT EXISTS suppliers (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name         TEXT NOT NULL,
  contact_name TEXT,
  email        TEXT,
  phone        TEXT,
  country      TEXT,
  is_active    BOOLEAN DEFAULT TRUE,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- SECTION 3 — CLIENT MANAGEMENT
-- ============================================================

-- 3.1 Organizations (Clients)
CREATE TABLE IF NOT EXISTS organization (
  id                 UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name               TEXT NOT NULL,
  slug               TEXT,
  client_code        TEXT UNIQUE,
  logo               TEXT,
  business_type      TEXT,
  contact_name       TEXT,
  contact_email      TEXT,
  contact_phone      TEXT,
  address            TEXT,
  city               TEXT,
  country            TEXT DEFAULT 'OM',
  tax_number         TEXT,
  account_manager_id UUID REFERENCES profiles(id),
  contract_start     DATE,
  contract_end       DATE,
  payment_terms      TEXT DEFAULT 'NET30',
  credit_limit       NUMERIC(14,2) DEFAULT 0,
  currency           TEXT DEFAULT 'OMR',
  needs_stockup      BOOLEAN DEFAULT FALSE,
  storage_type       TEXT,
  onboarding_status  TEXT DEFAULT 'pending'
    CHECK (onboarding_status IN ('pending','in_progress','active','suspended','churned')),
  is_active          BOOLEAN DEFAULT TRUE,
  is_integrated      BOOLEAN DEFAULT FALSE,
  default_warehouse_id UUID REFERENCES warehouses(id),
  notes              TEXT,
  custom_fields      JSONB DEFAULT '{}'::jsonb,
  merchant_code      TEXT,
  metadata           TEXT,
  created_by         UUID REFERENCES profiles(id),
  created_at         TIMESTAMPTZ DEFAULT NOW(),
  updated_at         TIMESTAMPTZ DEFAULT NOW()
);
COMMENT ON COLUMN organization.needs_stockup  IS 'Space3PL proactively manages stock replenishment';
COMMENT ON COLUMN organization.custom_fields  IS 'Flexible key-value store for client-specific fields';
COMMENT ON COLUMN organization.is_integrated  IS 'Has at least one active platform integration';

-- 3.2 Client Contacts
CREATE TABLE IF NOT EXISTS client_contacts (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organization(id) ON DELETE CASCADE,
  name            TEXT NOT NULL,
  position        TEXT,
  email           TEXT,
  phone           TEXT,
  whatsapp        TEXT,
  is_primary      BOOLEAN DEFAULT FALSE,
  is_billing      BOOLEAN DEFAULT FALSE,
  is_technical    BOOLEAN DEFAULT FALSE,
  notes           TEXT,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- 3.3 Platform Types (Shopify, Noon, Amazon, etc.)
CREATE TABLE IF NOT EXISTS platform_types (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name        TEXT NOT NULL,
  description TEXT,
  is_active   BOOLEAN DEFAULT TRUE,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

-- 3.4 Organization Platform Integrations
-- One row per client × sales channel. Stores API credentials + automation flags.
CREATE TABLE IF NOT EXISTS organization_platform (
  id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id      UUID NOT NULL REFERENCES organization(id) ON DELETE CASCADE,
  platform_id          UUID REFERENCES platform_types(id),
  name                 TEXT NOT NULL,          -- e.g. "Fashion World — Shopify"
  integration_type     TEXT,
  base_url             TEXT,                   -- e.g. https://store.myshopify.com
  api_endpoint         TEXT,
  webhook_endpoint     TEXT,                   -- Incoming webhook URL (NEXUS side)
  webhook_secret       TEXT,
  api_key              TEXT,
  api_secret           TEXT,
  api_username         TEXT,
  api_password         TEXT,
  -- Automation flags
  sync_orders          BOOLEAN DEFAULT TRUE,   -- Receive orders via webhook
  auto_fulfill         BOOLEAN DEFAULT FALSE,  -- Push fulfillment back to platform
  sync_inventory       BOOLEAN DEFAULT FALSE,  -- Push SOH levels to platform
  auto_cancel          BOOLEAN DEFAULT FALSE,  -- Sync cancellations from platform
  sync_frequency_mins  INT DEFAULT 15,
  last_synced_at       TIMESTAMPTZ,
  -- Order config
  order_prefix         TEXT,                   -- Prefix for order numbers from this platform
  test_mode            BOOLEAN DEFAULT FALSE,
  -- Status mapping: maps NEXUS statuses to platform-specific codes
  status_mapping       JSONB DEFAULT '{}'::jsonb,
  is_enabled           BOOLEAN DEFAULT TRUE,
  notes                TEXT,
  metadata             JSONB,
  created_by           UUID REFERENCES profiles(id),
  created_at           TIMESTAMPTZ DEFAULT NOW(),
  updated_at           TIMESTAMPTZ DEFAULT NOW()
);
COMMENT ON COLUMN organization_platform.status_mapping IS
  'Maps NEXUS statuses → platform codes. Example: {"dispatched":"fulfilled","delivered":"complete"}';
COMMENT ON COLUMN organization_platform.auto_fulfill IS
  'When TRUE: on dispatch in NEXUS, call platform API to push tracking + fulfillment status';

-- 3.5 Service Categories
CREATE TABLE IF NOT EXISTS service_categories (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name        TEXT NOT NULL,
  code        TEXT NOT NULL UNIQUE,
  description TEXT,
  is_active   BOOLEAN DEFAULT TRUE,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  updated_at  TIMESTAMPTZ DEFAULT NOW()
);

-- 3.6 Services (master catalog)
CREATE TABLE IF NOT EXISTS service (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name          TEXT,
  slug          TEXT,
  code          TEXT,
  description   TEXT,
  external_code TEXT,
  parent_id     UUID REFERENCES service(id),
  metadata      JSONB DEFAULT '{}'::jsonb,
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

-- 3.7 Organization Services (per-client pricing)
CREATE TABLE IF NOT EXISTS organization_services (
  id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID NOT NULL REFERENCES organization(id) ON DELETE CASCADE,
  service_id      UUID NOT NULL REFERENCES service(id),
  charge_amount   NUMERIC(12,3) NOT NULL,
  currency        TEXT DEFAULT 'OMR',
  is_active       BOOLEAN DEFAULT TRUE,
  description     TEXT,
  metadata        JSONB,
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- SECTION 4 — PRODUCTS & INVENTORY
-- ============================================================

-- 4.1 Products
CREATE TABLE IF NOT EXISTS products (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  organization_id UUID REFERENCES organization(id),
  sku           TEXT UNIQUE NOT NULL,
  name          TEXT NOT NULL,
  description   TEXT,
  category      TEXT,
  brand         TEXT,
  unit          TEXT DEFAULT 'pcs',
  weight_kg     NUMERIC(8,3),
  barcode       TEXT,
  emoji         TEXT DEFAULT '📦',
  has_expiry    BOOLEAN DEFAULT FALSE,
  reorder_point INT DEFAULT 10,
  cost_price    NUMERIC(12,4) DEFAULT 0,
  selling_price NUMERIC(12,4) DEFAULT 0,
  is_active     BOOLEAN DEFAULT TRUE,
  created_by    UUID REFERENCES profiles(id),
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

-- 4.2 Inventory Levels (SOH per bin)
CREATE TABLE IF NOT EXISTS inventory_levels (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id          UUID REFERENCES products(id) ON DELETE CASCADE,
  bin_id              UUID REFERENCES bin_locations(id),
  quantity_soh        INT NOT NULL DEFAULT 0,
  quantity_reserved   INT DEFAULT 0,
  quantity_available  INT GENERATED ALWAYS AS (quantity_soh - quantity_reserved) STORED,
  last_counted_at     TIMESTAMPTZ,
  updated_at          TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(product_id, bin_id)
);

-- 4.3 Inventory Movements (full audit log)
CREATE TABLE IF NOT EXISTS inventory_movements (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id     UUID REFERENCES products(id),
  bin_id         UUID REFERENCES bin_locations(id),
  movement_type  movement_type NOT NULL,
  quantity       INT NOT NULL,
  reference_id   UUID,
  reference_type TEXT,
  notes          TEXT,
  performed_by   UUID REFERENCES profiles(id),
  created_at     TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- SECTION 5 — ORDERS
-- ============================================================

-- 5.1 Status Types (lookup table)
CREATE TABLE IF NOT EXISTS status_types (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name       TEXT NOT NULL,
  category   TEXT NOT NULL,   -- 'order', 'payment_status', 'fulfillment_type', 'return'
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5.2 Orders
CREATE TABLE IF NOT EXISTS orders (
  id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number        TEXT UNIQUE NOT NULL,
  reference_number    TEXT,
  organization_id     UUID REFERENCES organization(id),
  platform_id         UUID REFERENCES organization_platform(id),  -- Which sales channel
  customer_id         UUID,
  is_draft            BOOLEAN DEFAULT FALSE,
  status_id           UUID REFERENCES status_types(id),
  payment_status_id   UUID REFERENCES status_types(id),
  fulfillment_type_id UUID REFERENCES status_types(id),
  delivery_status_id  UUID REFERENCES status_types(id),
  currency            TEXT DEFAULT 'OMR',
  subtotal            NUMERIC(12,2) DEFAULT 0,
  tax_amount          NUMERIC(12,2) DEFAULT 0,
  total_amount        NUMERIC(12,2) DEFAULT 0,
  total_weight        NUMERIC(8,3),
  total_items         INT DEFAULT 0,
  -- Shipping
  shipping_name       TEXT,
  shipping_phone      TEXT,
  shipping_email      TEXT,
  shipping_address1   TEXT,
  shipping_address2   TEXT,
  shipping_city       TEXT,
  shipping_zone       TEXT,
  shipping_postal     TEXT,
  shipping_country    TEXT DEFAULT 'OM',
  -- Flags
  is_cod              BOOLEAN DEFAULT FALSE,
  notes               TEXT,
  metadata            JSONB,
  placed_at           TIMESTAMPTZ,
  confirmed_at        TIMESTAMPTZ,
  posted_date         TIMESTAMPTZ,
  posted_by           UUID REFERENCES profiles(id),
  created_at          TIMESTAMPTZ DEFAULT NOW(),
  updated_at          TIMESTAMPTZ DEFAULT NOW()
);
COMMENT ON COLUMN orders.platform_id IS 'Links order to client sales channel for automation callbacks';

-- 5.3 Order Items
CREATE TABLE IF NOT EXISTS order_items (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id   UUID REFERENCES orders(id) ON DELETE CASCADE,
  product_id UUID REFERENCES products(id),
  quantity   INT NOT NULL DEFAULT 1,
  unit_price NUMERIC(12,4),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 5.4 Order Status History
CREATE TABLE IF NOT EXISTS order_status_history (
  id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id   UUID REFERENCES orders(id) ON DELETE CASCADE,
  status_id  UUID REFERENCES status_types(id),
  notes      TEXT,
  changed_by UUID REFERENCES profiles(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- SECTION 6 — WAREHOUSE OPERATIONS
-- ============================================================

-- 6.1 Inbound Receipts (GRN / Purchase Orders)
CREATE TABLE IF NOT EXISTS inbound_receipts (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  receipt_ref         TEXT UNIQUE NOT NULL,
  po_number           TEXT,
  supplier_id         UUID REFERENCES suppliers(id),
  carrier             TEXT,
  tracking_no         TEXT,
  expected_date       DATE,
  received_date       DATE,
  status              inbound_status DEFAULT 'expected',
  total_expected_qty  INT DEFAULT 0,
  total_received_qty  INT DEFAULT 0,
  notes               TEXT,
  received_by         UUID REFERENCES profiles(id),
  created_by          UUID REFERENCES profiles(id),
  created_at          TIMESTAMPTZ DEFAULT NOW(),
  updated_at          TIMESTAMPTZ DEFAULT NOW()
);

-- 6.2 Inbound Receipt Lines (per-SKU lines)
CREATE TABLE IF NOT EXISTS inbound_receipt_lines (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  receipt_id   UUID REFERENCES inbound_receipts(id) ON DELETE CASCADE,
  product_id   UUID REFERENCES products(id),
  expected_qty INT NOT NULL DEFAULT 0,
  received_qty INT DEFAULT 0,
  condition    item_condition DEFAULT 'good',
  bin_id       UUID REFERENCES bin_locations(id),
  discrepancy  INT GENERATED ALWAYS AS (received_qty - expected_qty) STORED,
  unit_cost    NUMERIC(12,4),
  notes        TEXT,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- 6.3 Picklists
CREATE TABLE IF NOT EXISTS picklists (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  picklist_ref  TEXT UNIQUE NOT NULL,
  method        picklist_method DEFAULT 'single',
  status        picklist_status DEFAULT 'pending',
  priority      priority_level DEFAULT 'normal',
  assigned_to   UUID REFERENCES profiles(id),
  created_by    UUID REFERENCES profiles(id),
  started_at    TIMESTAMPTZ,
  completed_at  TIMESTAMPTZ,
  notes         TEXT,
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  updated_at    TIMESTAMPTZ DEFAULT NOW()
);

-- 6.4 Picklist ↔ Order link
CREATE TABLE IF NOT EXISTS picklist_orders (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  picklist_id UUID REFERENCES picklists(id) ON DELETE CASCADE,
  order_id    UUID REFERENCES orders(id) ON DELETE CASCADE,
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(picklist_id, order_id)
);

-- 6.5 Picklist Items (individual pick lines)
CREATE TABLE IF NOT EXISTS picklist_items (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  picklist_id UUID REFERENCES picklists(id) ON DELETE CASCADE,
  order_id    UUID REFERENCES orders(id),
  product_id  UUID REFERENCES products(id),
  bin_id      UUID REFERENCES bin_locations(id),
  quantity    INT NOT NULL DEFAULT 1,
  picked_qty  INT DEFAULT 0,
  is_picked   BOOLEAN DEFAULT FALSE,
  picked_at   TIMESTAMPTZ,
  picked_by   UUID REFERENCES profiles(id),
  sort_order  INT DEFAULT 0,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- 6.6 Putaway Tasks
CREATE TABLE IF NOT EXISTS putaway_tasks (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  receipt_id       UUID REFERENCES inbound_receipts(id),
  receipt_line_id  UUID REFERENCES inbound_receipt_lines(id),
  product_id       UUID REFERENCES products(id),
  quantity         INT NOT NULL DEFAULT 0,
  suggested_bin_id UUID REFERENCES bin_locations(id),
  actual_bin_id    UUID REFERENCES bin_locations(id),
  status           putaway_status DEFAULT 'waiting',
  assigned_to      UUID REFERENCES profiles(id),
  completed_at     TIMESTAMPTZ,
  completed_by     UUID REFERENCES profiles(id),
  notes            TEXT,
  created_at       TIMESTAMPTZ DEFAULT NOW(),
  updated_at       TIMESTAMPTZ DEFAULT NOW()
);

-- 6.7 Packing Records
CREATE TABLE IF NOT EXISTS packing_records (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id      UUID REFERENCES orders(id) ON DELETE CASCADE,
  picklist_id   UUID REFERENCES picklists(id),
  box_type      TEXT,
  weight_kg     NUMERIC(8,3),
  bubble_wrap   BOOLEAN DEFAULT FALSE,
  fragile_label BOOLEAN DEFAULT FALSE,
  special_notes TEXT,
  packed_by     UUID REFERENCES profiles(id),
  packed_at     TIMESTAMPTZ DEFAULT NOW(),
  label_printed BOOLEAN DEFAULT FALSE,
  created_at    TIMESTAMPTZ DEFAULT NOW()
);

-- 6.8 Cycle Counts
CREATE TABLE IF NOT EXISTS cycle_counts (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  count_ref      TEXT UNIQUE NOT NULL,
  zone_id        UUID REFERENCES zones(id),
  status         cycle_count_status DEFAULT 'scheduled',
  scheduled_date DATE,
  started_at     TIMESTAMPTZ,
  submitted_at   TIMESTAMPTZ,
  approved_at    TIMESTAMPTZ,
  assigned_to    UUID REFERENCES profiles(id),
  approved_by    UUID REFERENCES profiles(id),
  notes          TEXT,
  created_at     TIMESTAMPTZ DEFAULT NOW()
);

-- 6.9 Cycle Count Items
CREATE TABLE IF NOT EXISTS cycle_count_items (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  count_id    UUID REFERENCES cycle_counts(id) ON DELETE CASCADE,
  product_id  UUID REFERENCES products(id),
  bin_id      UUID REFERENCES bin_locations(id),
  system_qty  INT NOT NULL DEFAULT 0,
  counted_qty INT,
  variance    INT GENERATED ALWAYS AS (COALESCE(counted_qty, 0) - system_qty) STORED,
  is_approved BOOLEAN DEFAULT FALSE,
  counted_by  UUID REFERENCES profiles(id),
  counted_at  TIMESTAMPTZ,
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- SECTION 7 — INDEXES
-- ============================================================
CREATE INDEX IF NOT EXISTS idx_inv_product       ON inventory_levels(product_id);
CREATE INDEX IF NOT EXISTS idx_inv_bin            ON inventory_levels(bin_id);
CREATE INDEX IF NOT EXISTS idx_orders_org         ON orders(organization_id);
CREATE INDEX IF NOT EXISTS idx_orders_platform    ON orders(platform_id);
CREATE INDEX IF NOT EXISTS idx_orders_status      ON orders(status_id);
CREATE INDEX IF NOT EXISTS idx_picklist_status    ON picklists(status);
CREATE INDEX IF NOT EXISTS idx_picklist_assigned  ON picklists(assigned_to);
CREATE INDEX IF NOT EXISTS idx_picklist_items_pl  ON picklist_items(picklist_id);
CREATE INDEX IF NOT EXISTS idx_putaway_status     ON putaway_tasks(status);
CREATE INDEX IF NOT EXISTS idx_movements_product  ON inventory_movements(product_id);
CREATE INDEX IF NOT EXISTS idx_movements_created  ON inventory_movements(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_inbound_status     ON inbound_receipts(status);
CREATE INDEX IF NOT EXISTS idx_client_contacts    ON client_contacts(organization_id);
CREATE INDEX IF NOT EXISTS idx_org_platform       ON organization_platform(organization_id);

-- ============================================================
-- SECTION 8 — VIEWS
-- ============================================================
CREATE OR REPLACE VIEW v_inventory_soh AS
  SELECT
    p.id AS product_id, p.sku, p.name, p.emoji, p.category, p.reorder_point,
    b.code AS bin_code, z.code AS zone_code, z.name AS zone_name,
    il.quantity_soh, il.quantity_reserved, il.quantity_available
  FROM inventory_levels il
  JOIN products        p ON p.id = il.product_id
  JOIN bin_locations   b ON b.id = il.bin_id
  JOIN zones           z ON z.id = b.zone_id;

CREATE OR REPLACE VIEW v_orders_summary AS
  SELECT
    o.id, o.order_number, o.organization_id, o.platform_id,
    o.status_id, o.total_amount, o.created_at,
    org.name AS client_name,
    op.name  AS platform_name,
    COUNT(oi.id) AS item_count,
    SUM(oi.quantity) AS total_units
  FROM orders o
  LEFT JOIN organization         org ON org.id = o.organization_id
  LEFT JOIN organization_platform op  ON op.id  = o.platform_id
  LEFT JOIN order_items          oi  ON oi.order_id = o.id
  GROUP BY o.id, org.name, op.name;

CREATE OR REPLACE VIEW v_putaway_queue AS
  SELECT
    pt.id, pt.status AS task_status, pt.quantity,
    p.sku, p.name AS product_name, p.emoji,
    ir.receipt_ref, ir.po_number,
    sb.code AS suggested_bin,
    z.code  AS zone_code,
    prof.full_name AS assigned_to_name
  FROM putaway_tasks pt
  JOIN products         p    ON p.id    = pt.product_id
  JOIN inbound_receipts ir   ON ir.id   = pt.receipt_id
  LEFT JOIN bin_locations sb ON sb.id   = pt.suggested_bin_id
  LEFT JOIN zones         z  ON z.id    = sb.zone_id
  LEFT JOIN profiles      prof ON prof.id = pt.assigned_to
  WHERE pt.status::TEXT != 'complete';

-- ============================================================
-- SECTION 9 — FUNCTIONS & TRIGGERS
-- ============================================================

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE TRIGGER trg_profiles_updated    BEFORE UPDATE ON profiles            FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE OR REPLACE TRIGGER trg_orders_updated       BEFORE UPDATE ON orders              FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE OR REPLACE TRIGGER trg_org_updated          BEFORE UPDATE ON organization        FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE OR REPLACE TRIGGER trg_org_platform_updated BEFORE UPDATE ON organization_platform FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE OR REPLACE TRIGGER trg_inventory_updated    BEFORE UPDATE ON inventory_levels    FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE OR REPLACE TRIGGER trg_inbound_updated      BEFORE UPDATE ON inbound_receipts    FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE OR REPLACE TRIGGER trg_picklist_updated     BEFORE UPDATE ON picklists           FOR EACH ROW EXECUTE FUNCTION update_updated_at();
CREATE OR REPLACE TRIGGER trg_putaway_updated      BEFORE UPDATE ON putaway_tasks       FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- adjust_stock: update inventory and log movement atomically
CREATE OR REPLACE FUNCTION adjust_stock(
  p_product_id     UUID,
  p_bin_id         UUID,
  p_quantity       INT,
  p_type           movement_type,
  p_reference_id   UUID    DEFAULT NULL,
  p_reference_type TEXT    DEFAULT NULL,
  p_performed_by   UUID    DEFAULT NULL,
  p_notes          TEXT    DEFAULT NULL
) RETURNS VOID AS $$
BEGIN
  INSERT INTO inventory_levels (product_id, bin_id, quantity_soh)
    VALUES (p_product_id, p_bin_id, GREATEST(0, p_quantity))
  ON CONFLICT (product_id, bin_id)
  DO UPDATE SET
    quantity_soh = GREATEST(0, inventory_levels.quantity_soh + p_quantity),
    updated_at   = NOW();

  INSERT INTO inventory_movements
    (product_id, bin_id, movement_type, quantity, reference_id, reference_type, performed_by, notes)
  VALUES
    (p_product_id, p_bin_id, p_type, p_quantity, p_reference_id, p_reference_type, p_performed_by, p_notes);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================
-- SECTION 10 — ROW LEVEL SECURITY (RLS)
-- ============================================================

-- Enable RLS on all tables
ALTER TABLE profiles               ENABLE ROW LEVEL SECURITY;
ALTER TABLE warehouses             ENABLE ROW LEVEL SECURITY;
ALTER TABLE zones                  ENABLE ROW LEVEL SECURITY;
ALTER TABLE bin_locations          ENABLE ROW LEVEL SECURITY;
ALTER TABLE suppliers              ENABLE ROW LEVEL SECURITY;
ALTER TABLE products               ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory_levels       ENABLE ROW LEVEL SECURITY;
ALTER TABLE inventory_movements    ENABLE ROW LEVEL SECURITY;
ALTER TABLE organization           ENABLE ROW LEVEL SECURITY;
ALTER TABLE client_contacts        ENABLE ROW LEVEL SECURITY;
ALTER TABLE platform_types         ENABLE ROW LEVEL SECURITY;
ALTER TABLE organization_platform  ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_categories     ENABLE ROW LEVEL SECURITY;
ALTER TABLE service                ENABLE ROW LEVEL SECURITY;
ALTER TABLE organization_services  ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders                 ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_items            ENABLE ROW LEVEL SECURITY;
ALTER TABLE order_status_history   ENABLE ROW LEVEL SECURITY;
ALTER TABLE inbound_receipts       ENABLE ROW LEVEL SECURITY;
ALTER TABLE inbound_receipt_lines  ENABLE ROW LEVEL SECURITY;
ALTER TABLE picklists              ENABLE ROW LEVEL SECURITY;
ALTER TABLE picklist_orders        ENABLE ROW LEVEL SECURITY;
ALTER TABLE picklist_items         ENABLE ROW LEVEL SECURITY;
ALTER TABLE putaway_tasks          ENABLE ROW LEVEL SECURITY;
ALTER TABLE packing_records        ENABLE ROW LEVEL SECURITY;
ALTER TABLE cycle_counts           ENABLE ROW LEVEL SECURITY;
ALTER TABLE cycle_count_items      ENABLE ROW LEVEL SECURITY;

-- RLS Helper Functions
CREATE OR REPLACE FUNCTION auth_role()
RETURNS user_role AS $$
  SELECT role FROM profiles WHERE id = auth.uid();
$$ LANGUAGE sql SECURITY DEFINER STABLE;

CREATE OR REPLACE FUNCTION is_admin()
RETURNS BOOLEAN AS $$
  SELECT auth_role() IN ('super_admin','admin','manager');
$$ LANGUAGE sql SECURITY DEFINER STABLE;

-- Drop all existing policies before recreating (avoids duplicates)
DO $$ DECLARE r RECORD;
BEGIN
  FOR r IN SELECT policyname, tablename
           FROM pg_policies WHERE schemaname = 'public'
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON %I', r.policyname, r.tablename);
  END LOOP;
END $$;

-- Profiles
CREATE POLICY "profiles_read"       ON profiles FOR SELECT USING (id = auth.uid() OR is_admin());
CREATE POLICY "profiles_update_own" ON profiles FOR UPDATE USING (id = auth.uid());
CREATE POLICY "profiles_admin"      ON profiles FOR ALL    USING (is_admin());

-- Reference tables — everyone authenticated reads, admins write
CREATE POLICY "warehouses_read"  ON warehouses   FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "warehouses_admin" ON warehouses   FOR ALL    USING (is_admin());
CREATE POLICY "zones_read"       ON zones        FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "zones_admin"      ON zones        FOR ALL    USING (is_admin());
CREATE POLICY "bins_read"        ON bin_locations FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "bins_admin"       ON bin_locations FOR ALL    USING (is_admin());
CREATE POLICY "suppliers_read"   ON suppliers    FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "suppliers_admin"  ON suppliers    FOR ALL    USING (is_admin());
CREATE POLICY "platform_read"    ON platform_types FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "platform_admin"   ON platform_types FOR ALL    USING (is_admin());
CREATE POLICY "svc_cat_read"     ON service_categories FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "svc_cat_admin"    ON service_categories FOR ALL    USING (is_admin());
CREATE POLICY "svc_read"         ON service      FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "svc_admin"        ON service      FOR ALL    USING (is_admin());

-- Products — all read, warehouse+admin write
CREATE POLICY "products_read"  ON products FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "products_write" ON products FOR ALL
  USING (auth_role() IN ('super_admin','admin','manager','warehouse'));

-- Inventory — all read, warehouse+admin write
CREATE POLICY "inv_read"   ON inventory_levels    FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "inv_write"  ON inventory_levels    FOR ALL    USING (auth_role() IN ('super_admin','admin','manager','warehouse'));
CREATE POLICY "mov_read"   ON inventory_movements FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "mov_admin"  ON inventory_movements FOR ALL    USING (is_admin());

-- Clients (organization) — admin+manager manage, others read
CREATE POLICY "org_read"   ON organization          FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "org_admin"  ON organization          FOR ALL    USING (is_admin());
CREATE POLICY "cc_read"    ON client_contacts       FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "cc_admin"   ON client_contacts       FOR ALL    USING (is_admin());
CREATE POLICY "op_read"    ON organization_platform FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "op_admin"   ON organization_platform FOR ALL    USING (is_admin());
CREATE POLICY "os_read"    ON organization_services FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "os_admin"   ON organization_services FOR ALL    USING (is_admin());

-- Orders — all authenticated read, admin+manager write
CREATE POLICY "orders_read"  ON orders              FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "orders_write" ON orders              FOR ALL    USING (auth_role() IN ('super_admin','admin','manager'));
CREATE POLICY "oi_read"      ON order_items         FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "oi_write"     ON order_items         FOR ALL    USING (auth_role() IN ('super_admin','admin','manager'));
CREATE POLICY "osh_read"     ON order_status_history FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "osh_write"    ON order_status_history FOR ALL   USING (auth_role() IN ('super_admin','admin','manager'));

-- Inbound — receiver+warehouse+admin write
CREATE POLICY "inbound_read"    ON inbound_receipts      FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "inbound_write"   ON inbound_receipts      FOR ALL    USING (auth_role() IN ('super_admin','admin','manager','warehouse','receiver'));
CREATE POLICY "inb_ln_read"     ON inbound_receipt_lines FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "inb_ln_write"    ON inbound_receipt_lines FOR ALL    USING (auth_role() IN ('super_admin','admin','manager','warehouse','receiver'));

-- Picklists — pickers see own + assigned; admins see all
CREATE POLICY "pl_admin"     ON picklists      FOR ALL    USING (is_admin());
CREATE POLICY "pl_own_read"  ON picklists      FOR SELECT USING (assigned_to = auth.uid());
CREATE POLICY "pl_own_upd"   ON picklists      FOR UPDATE USING (assigned_to = auth.uid());
CREATE POLICY "plo_read"     ON picklist_orders FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "plo_admin"    ON picklist_orders FOR ALL    USING (is_admin());
CREATE POLICY "pli_read"     ON picklist_items  FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "pli_pick"     ON picklist_items  FOR UPDATE USING (auth_role() IN ('super_admin','admin','manager','warehouse','picker'));
CREATE POLICY "pli_admin"    ON picklist_items  FOR ALL    USING (is_admin());

-- Putaway — warehouse+receiver+admin write
CREATE POLICY "putaway_read"  ON putaway_tasks  FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "putaway_write" ON putaway_tasks  FOR ALL    USING (auth_role() IN ('super_admin','admin','manager','warehouse','receiver'));

-- Packing — packer+admin write
CREATE POLICY "pack_read"  ON packing_records FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "pack_write" ON packing_records FOR ALL    USING (auth_role() IN ('super_admin','admin','manager','warehouse','packer'));

-- Cycle counts — warehouse+admin
CREATE POLICY "cyc_read"  ON cycle_counts      FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "cyc_write" ON cycle_counts      FOR ALL    USING (auth_role() IN ('super_admin','admin','manager','warehouse'));
CREATE POLICY "cci_read"  ON cycle_count_items FOR SELECT USING (auth.uid() IS NOT NULL);
CREATE POLICY "cci_write" ON cycle_count_items FOR ALL    USING (auth_role() IN ('super_admin','admin','manager','warehouse'));

-- ============================================================
-- SECTION 11 — SEED DATA
-- ============================================================

-- Default warehouse
INSERT INTO warehouses (id, name, address, city, country)
VALUES ('00000000-0000-0000-0000-000000000001', 'Space3PL Muscat', 'Al Mawaleh South Industrial Area', 'Muscat', 'OM')
ON CONFLICT (id) DO NOTHING;

-- Zones
DO $$
DECLARE w UUID := '00000000-0000-0000-0000-000000000001';
BEGIN
  INSERT INTO zones (warehouse_id, code, name, category, color, total_bins) VALUES
    (w,'A','Zone A — Fashion',     'Fashion',     '#0ea5e9',200),
    (w,'B','Zone B — Electronics', 'Electronics', '#8b5cf6',200),
    (w,'C','Zone C — Beauty',      'Beauty',      '#ec4899',200),
    (w,'D','Zone D — Home Goods',  'Home Goods',  '#22c55e',200),
    (w,'E','Zone E — Oversize',    'Oversize',    '#f59e0b',100)
  ON CONFLICT (warehouse_id, code) DO NOTHING;
END $$;

-- Suppliers
INSERT INTO suppliers (name, contact_name, email, country) VALUES
  ('Fashion World Co.',  'Khalid Al-Farsi', 'khalid@fashionworld.com', 'AE'),
  ('ElecTech Suppliers', 'Raj Kumar',       'raj@electech.com',        'IN'),
  ('BeautyCare Ltd',     'Sara Ahmed',      'sara@beautycare.com',     'GB'),
  ('HomeStyle Imports',  'Chen Wei',        'chen@homestyle.com',      'CN')
ON CONFLICT DO NOTHING;

-- Order status types
INSERT INTO status_types (id, name, category) VALUES
  ('867b98c6-63db-410d-aa6e-5d8912861bd8', 'Pending',    'order'),
  ('d83ede6d-e792-497b-b007-2b1fdfa7f496', 'Confirmed',  'order'),
  ('a88d9fed-15be-448a-96cb-841a4a95b6ff', 'Processing', 'order'),
  ('9a96c0e0-b31c-436c-8462-66f910fa9a34', 'Shipped',    'order'),
  ('5b12000d-0550-48b5-b511-b2fc84e6c2dc', 'Delivered',  'order'),
  ('39e2d9c7-54fc-4c9f-b633-0fb79256176b', 'Cancelled',  'order'),
  ('1b902637-368f-4d63-93b7-c2ff040253f5', 'Returned',   'order'),
  ('045d0dbd-5e49-44ab-9da9-78794a31ffa0', 'Paid',           'payment_status'),
  ('7b802761-2b82-44c6-9ea3-00d01d4766c4', 'Partially Paid', 'payment_status'),
  ('86bc4270-4ba5-418a-b461-73f7c4883305', 'Unpaid',         'payment_status'),
  ('ad818d8c-d21f-4a3b-91d0-0abccdf06958', 'Home Delivery',  'fulfillment_type'),
  ('2753f4d2-ad43-4684-8a7e-bb35f0d8872f', 'Store Pickup',   'fulfillment_type'),
  ('8a4c4bbb-4815-45bc-ad64-d7df9e539a32', 'Pending',    'return'),
  ('0b961c39-db54-46f8-89c2-8878b8184a9c', 'Received',   'return'),
  ('b6251da7-e0d9-423d-8eb9-3fec6d09733c', 'Processed',  'return')
ON CONFLICT (id) DO NOTHING;

-- Platform types (sales channels)
INSERT INTO platform_types (name, description) VALUES
  ('Shopify',          'Shopify e-commerce store'),
  ('WooCommerce',      'WordPress WooCommerce'),
  ('Magento',          'Magento / Adobe Commerce'),
  ('OpenCart',         'OpenCart store'),
  ('Noon',             'Noon.com marketplace'),
  ('Amazon',           'Amazon Seller Central'),
  ('TikTok Shop',      'TikTok Shop integration'),
  ('Instagram Shop',   'Instagram / Facebook Shop'),
  ('WhatsApp Commerce','WhatsApp Commerce API'),
  ('Salla',            'Salla (Saudi/GCC)'),
  ('Zid',              'Zid (Saudi/GCC)'),
  ('Custom API',       'Custom REST API'),
  ('Manual',           'Manual order entry — no integration')
ON CONFLICT DO NOTHING;

-- Service categories
INSERT INTO service_categories (name, code, description) VALUES
  ('Fulfillment', 'FULFILL',  'Order picking, packing and dispatch'),
  ('Storage',     'STORAGE',  'Warehouse storage and inventory management'),
  ('Inbound',     'INBOUND',  'Receiving, QC and putaway'),
  ('Returns',     'RETURNS',  'Returns processing and disposition'),
  ('Value Added', 'VAS',      'Kitting, bundling, labelling, gift wrap'),
  ('Delivery',    'DELIVERY', 'Last-mile delivery services'),
  ('Technology',  'TECH',     'Platform integration and WMS access'),
  ('Consulting',  'CONSULT',  'Onboarding and operational consulting')
ON CONFLICT (code) DO NOTHING;

-- Services catalog
INSERT INTO service (name, slug, code, description) VALUES
  ('Pick & Pack — Single Item',   'pick-pack-single',  'FF-001', 'Pick and pack — 1 item per order'),
  ('Pick & Pack — Multi Item',    'pick-pack-multi',   'FF-002', 'Pick and pack — 2+ items per order'),
  ('Same-Day Fulfillment',        'same-day-fulfill',  'FF-003', 'Same-day order dispatch guarantee'),
  ('Branded Packaging',           'branded-pack',      'FF-004', 'Client-branded box/bag packing'),
  ('Storage per Pallet/Month',    'storage-pallet',    'ST-001', 'Monthly storage fee per pallet'),
  ('Storage per Shelf/Month',     'storage-shelf',     'ST-002', 'Monthly storage fee per shelf'),
  ('Storage per Unit/Month',      'storage-unit',      'ST-003', 'Monthly per-unit storage fee'),
  ('Receiving & QC',              'receiving-qc',      'IB-001', 'Inbound receiving and quality check'),
  ('Putaway Service',             'putaway-svc',       'IB-002', 'Putaway to designated bin'),
  ('Barcode Labelling',           'barcode-label',     'IB-003', 'Applying barcodes/SKU labels on arrival'),
  ('Returns Processing',          'returns-process',   'RT-001', 'Inspect, grade and disposition returns'),
  ('Return to Supplier',          'rts-svc',           'RT-002', 'Returning items to supplier'),
  ('Kitting & Assembly',          'kitting-svc',       'VA-001', 'Assembling multi-SKU kits'),
  ('Gift Wrapping',               'gift-wrap-svc',     'VA-002', 'Gift wrapping with card'),
  ('Product Photography',         'photography-svc',   'VA-003', 'Basic product photography on receipt'),
  ('Shrink Wrapping',             'shrink-wrap-svc',   'VA-004', 'Shrink wrapping per unit'),
  ('Last-Mile Delivery — Muscat', 'delivery-muscat',   'DL-001', 'Same/next day delivery within Muscat'),
  ('Nationwide Delivery',         'delivery-national', 'DL-002', '48hr delivery across Oman'),
  ('Cash on Delivery Handling',   'cod-handling-svc',  'DL-003', 'COD collection and remittance'),
  ('WMS Access Fee',              'wms-access-svc',    'TK-001', 'Monthly WMS platform access fee'),
  ('API Integration Setup',       'api-setup-svc',     'TK-002', 'One-time integration setup fee'),
  ('Webhook Configuration',       'webhook-cfg-svc',   'TK-003', 'Webhook setup and testing')
ON CONFLICT DO NOTHING;

-- Sample products
INSERT INTO products (sku, name, category, emoji, cost_price, selling_price, reorder_point) VALUES
  ('ELEC-001', 'Pro Mechanical Keyboard',   'Electronics', '⌨️',  89.99, 149.99, 5),
  ('ELEC-002', 'Wireless Headphones Pro',   'Electronics', '🎧', 120.00, 229.99, 5),
  ('ELEC-004', 'USB-C Hub 7-Port',          'Electronics', '🔌',  35.00,  79.99, 10),
  ('FSH-001',  'Women Abaya - Black L',     'Fashion',     '👗',  25.00,  65.00, 20),
  ('FSH-003',  'Kids Dress - Floral M',     'Fashion',     '👗',  18.00,  45.00, 15),
  ('BEA-007',  'Argan Oil Serum 50ml',      'Beauty',      '🧴',  12.00,  38.00, 30),
  ('HOME-011', 'Scented Candle Set 3pc',    'Home Goods',  '🕯️',   8.00,  28.00, 15),
  ('FSH-021',  'Men''s Casual Polo - Blue', 'Fashion',     '👕',  14.00,  39.00, 20)
ON CONFLICT (sku) DO NOTHING;

-- ============================================================
-- SECTION 12 — ADMIN USER
-- ============================================================
-- Creates the default Super Admin account.
-- Email: admin@space3pl.com  |  Password: Space3PL@2026
-- Change the password after first login!

DO $$
DECLARE admin_id UUID := 'dfaaf68d-17dc-4962-9d30-5dd415961582';
BEGIN
  -- Create auth user (skip if already exists)
  IF NOT EXISTS (SELECT 1 FROM auth.users WHERE id = admin_id) THEN
    INSERT INTO auth.users (
      instance_id, id, aud, role, email, encrypted_password,
      email_confirmed_at, raw_app_meta_data, raw_user_meta_data,
      is_super_admin, created_at, updated_at,
      confirmation_token, email_change, email_change_token_new, recovery_token
    ) VALUES (
      '00000000-0000-0000-0000-000000000000',
      admin_id, 'authenticated', 'authenticated',
      'admin@space3pl.com',
      crypt('Space3PL@2026', gen_salt('bf')),
      NOW(),
      '{"provider":"email","providers":["email"]}',
      '{"full_name":"Space3PL Admin"}',
      FALSE, NOW(), NOW(), '', '', '', ''
    );
  END IF;

  -- Create identity row (required for email/password sign-in)
  IF NOT EXISTS (SELECT 1 FROM auth.identities WHERE user_id = admin_id) THEN
    INSERT INTO auth.identities (
      id, provider_id, user_id, identity_data, provider,
      last_sign_in_at, created_at, updated_at
    ) VALUES (
      gen_random_uuid(), 'admin@space3pl.com', admin_id,
      format('{"sub":"%s","email":"admin@space3pl.com"}', admin_id)::jsonb,
      'email', NOW(), NOW(), NOW()
    );
  END IF;

  -- Create profile
  INSERT INTO profiles (
    id, full_name, employee_id, role, email, department,
    pin, is_active, permissions, created_at, updated_at
  ) VALUES (
    admin_id, 'Space3PL Admin', 'EMP-001', 'super_admin',
    'admin@space3pl.com', 'Management', '1234', TRUE,
    '{"orders":{"view":true,"create":true,"edit":true,"delete":true},
      "inventory":{"view":true,"adjust":true},
      "clients":{"view":true,"manage":true},
      "reports":{"view":true},
      "settings":{"view":true,"manage":true},
      "users":{"view":true,"manage":true}}',
    NOW(), NOW()
  ) ON CONFLICT (id) DO NOTHING;
END $$;

-- ============================================================
-- END OF SCHEMA
-- ============================================================
