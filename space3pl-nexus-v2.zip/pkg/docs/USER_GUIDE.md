# Admin Panel User Guide — NEXUS

Complete guide for using the NEXUS Admin Panel at `/admin`.

---

## Signing In

| Version | Login Method |
|---------|-------------|
| `admin/index.html` | Email + Password (Supabase Auth) |
| `admin/index-no-login.html` | Opens directly — no login required |

**Default credentials:**
- Email: `admin@space3pl.com`
- Password: `Space3PL@2026`

---

## Dashboard

The dashboard loads automatically after login and shows:
- **Active Inbounds** — POs currently expected or being received
- **Open Picklists** — Picklists in pending/assigned/picking status
- **Putaway Queue** — Items waiting to be put away
- **Total Products** — Active SKU count
- Recent inbounds table, active picklists table, putaway queue snapshot

---

## Warehouse Module

### Inbound Receipts
Manage all incoming stock from suppliers.

1. Click **+ New Inbound** to create a PO
2. Fill in supplier, expected date, carrier, and PO number
3. When stock arrives, click **📥 Receive** on the receipt
4. Enter actual received quantities per line and condition (Good / Damaged / Wrong Item)
5. Click **✅ Complete & Create Putaway Tasks** — putaway tasks are auto-created
6. Click **🗺️ Putaway** from the receipt card to go to the putaway queue

### Picklist Generator
Create and manage pick orders for warehouse staff.

**Auto-Generate:** Click **⚡ Auto-Generate** to batch all ready orders automatically.

**Manual Create:** Click **+ New Picklist** and:
1. Select method: Single / Batch / Zone
2. Set priority: Normal / Urgent / VIP
3. Assign to a picker
4. Click **Generate Picklist**

**Send to WMS App:** Click **📱 Send to WMS App** on any picklist — the picker will see it in their mobile app.

### Putaway Queue
Assign and track post-receiving putaway tasks.

- **Auto-Assign** — distributes all unassigned tasks evenly across available warehouse staff
- **Assign** — manually assign a task to a specific person
- **✓ Done** — mark a task as complete (updates inventory automatically)
- Zone occupancy chart shows how full each zone is

### Zones & Bins
View the warehouse zone configuration — codes, names, categories and total bins.

### Cycle Counts
Schedule and manage stock counts.

1. Click **+ New Count**
2. Select zone, date and assign to a staff member
3. The staff member completes the count in the WMS Mobile App
4. Variances appear automatically and are flagged for supervisor approval

---

## Inventory Module

### Stock on Hand
Live view of all inventory from the `v_inventory_soh` database view. Shows:
- SOH (stock on hand), Reserved, Available quantities
- Bin location and zone per product
- Low stock alert when available ≤ reorder point (shown in red)

Search by SKU or product name.

### Movements
Full audit trail of every stock change — inbound receipts, picks, adjustments, returns, cycle count corrections.

---

## Orders Module

Shows all orders from your database. Uses the `status_types` table for status names.

The `platform_id` column on each order links it to the client's sales channel — this is what powers the auto-fulfill callback when you dispatch.

---

## Clients Module

### All Clients
Manage your client directory.

**Creating a client:**
1. Click **+ New Client**
2. **Info tab:** Company name, business type, contact details, country, account manager, stockup flag, storage type
3. **Contacts tab:** Add multiple contact people with roles (Primary / Billing / Technical)
4. **Integration tab:** Toggle "Yes — API integration" to flag this client as integrated
5. **Contract tab:** Contract dates, payment terms, credit limit, currency
6. **Custom Fields tab:** Add any extra fields specific to this client (e.g. "Shopify Store ID", "Priority Tier")
7. Click **Save Client**

After saving, click **🔌 Platforms** on a client to add their sales channel integrations.

### Client Services
Assign specific services to clients with custom pricing.

1. View the **Service Catalog** at the top (22 services across 8 categories)
2. Click **+ Assign Service**
3. Select client, service, charge amount and currency
4. Click **Assign Service**

Services are used to generate monthly invoices for clients.

---

## User Management

Create and manage all staff accounts.

**Creating a user:**
1. Click **+ Create User**
2. **Info tab:** Full name, Employee ID, email, phone, department, shift, hire date
3. **Role & Permissions tab:**
   - Select a system role (e.g. Picker, Warehouse, Manager)
   - Permissions grid auto-fills based on role
   - Adjust individual permissions as needed
4. **Login Access tab:**
   - Enter login email and temporary password (Admin Panel login)
   - Enter WMS PIN (4–6 digits — for WMS Mobile App login)
5. Click **Save User**

**Deactivating a user:** Click **Deactivate** on any user row — they can no longer log in.

---

## Settings

### Platforms Tab
Manage sales channel integrations for all clients.

**Adding a platform type:**
Click **+ Add Type** to add a new platform (e.g. a new marketplace).

**Adding a client integration:**
1. Click **+ Add Integration**
2. **Credentials tab:** Select client, platform type, enter API key/secret, webhook URL
3. **Automation tab:** Enable/disable:
   - **Sync Orders** — receive orders via webhook
   - **Auto-Fulfill Callback** — push tracking back to platform on dispatch
   - **Inventory Sync** — push SOH levels to platform
   - **Auto-Cancel Sync** — sync cancellations from platform
4. **Status Mapping tab:** Map NEXUS statuses to platform-specific status codes
5. Click **🧪 Test Connection** to verify the API URL responds
6. Click **Save Integration**

**The automation flow in practice:**
- Order arrives via webhook → NEXUS auto-creates it with `platform_id` set
- Your team picks/packs/dispatches the order
- If Auto-Fulfill is ON: NEXUS calls the platform API and pushes the fulfillment + tracking number
- The platform marks the order as fulfilled for the customer automatically

### General Tab
Company name, default currency, default warehouse, timezone.

---

## SDK vs REST Toggle

The top bar has a **SDK / REST** toggle. This switches whether data is fetched using:
- **SDK** — Supabase JavaScript SDK (default)
- **REST** — Plain `fetch()` calls directly to the Supabase REST API

Both produce identical results. Useful for debugging or understanding how the queries work.

---

*Space3PL NEXUS Admin Panel Guide — v2.0 — 2026*
