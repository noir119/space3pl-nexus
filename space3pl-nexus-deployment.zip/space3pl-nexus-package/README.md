# Space3PL NEXUS — Warehouse Management Platform

Full-stack warehouse + client management system for Space3PL Oman.

## Applications
- **`/admin`** — NEXUS Admin Panel (desktop/tablet enterprise dashboard)
- **`/wms`** — WMS Mobile App (warehouse staff handheld app)

## Admin Panel Modules
| Module | Features |
|---|---|
| Dashboard | Live KPIs, inbound / picklist / putaway snapshots |
| Warehouse | Inbound Receipts, Picklist Generator, Putaway Queue, Zones & Bins, Cycle Counts |
| Inventory | Stock on Hand (SOH), Movements audit trail |
| Orders | Full order management with status tracking |
| **Clients** | **Client directory, contacts, integration flags, contract & custom fields** |
| **Client Services** | **Service catalog, per-client pricing & charge assignment** |
| **User Management** | **Create staff, assign roles, granular permissions, WMS PIN** |
| **Settings → Platforms** | **Platform types, per-client integrations, automation config, status mapping** |

## WMS Mobile App Screens
Picking · Packing · Inbound Receiving · Putaway · Cycle Count · Stock Lookup

## Tech Stack
Vanilla HTML/CSS/JS · Supabase JS SDK v2 · REST API fallback · Vercel (static)

## Supabase Project
`eqmjdojaqzaakmbcsakc` · EU West 2 (London)

## First-Time Setup
1. Supabase → Authentication → Add User (email + password)
2. Table Editor → `profiles` → insert row with UUID, `full_name`, `role = super_admin`
3. Open `/admin` and sign in

*Space3PL Oman · 2026*
