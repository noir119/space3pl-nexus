# Deployment Guide — Space3PL NEXUS

Complete step-by-step instructions to deploy both apps to Vercel via GitHub.

---

## Prerequisites

- A [GitHub](https://github.com) account
- A [Vercel](https://vercel.com) account (free tier is enough)
- Your Supabase project already set up (schema.sql already run)
- This repository downloaded/extracted to your computer

---

## Step 1 — Set Up the Database

If you haven't run the schema yet:

1. Go to [supabase.com](https://supabase.com) → open your project
2. Click **SQL Editor** in the left sidebar
3. Click **New Query**
4. Open `supabase/schema.sql` from this package, copy all contents, paste into the editor
5. Click **Run** (the green button)
6. Wait about 30 seconds — you will see "Success" messages
7. Done — all tables, RLS policies, seed data and admin user are now created

---

## Step 2 — Create GitHub Repository

1. Go to [github.com/new](https://github.com/new)
2. Repository name: `space3pl-nexus`
3. Visibility: **Private** (recommended) or Public
4. **Do NOT** tick "Add a README file" — leave everything unchecked
5. Click **Create repository**
6. Copy the repository URL shown (e.g. `https://github.com/YOUR_USERNAME/space3pl-nexus.git`)

---

## Step 3 — Push Files to GitHub

Open a terminal (Windows: Command Prompt or PowerShell, Mac/Linux: Terminal).

Navigate into the extracted package folder:

```bash
cd path/to/space3pl-nexus-package
```

Run these commands one by one:

```bash
git init
git add -A
git commit -m "Initial deployment — Space3PL NEXUS v2.0"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/space3pl-nexus.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your actual GitHub username.

When prompted, enter your GitHub username and password (or personal access token if you have 2FA enabled).

---

## Step 4 — Deploy to Vercel

1. Go to [vercel.com](https://vercel.com) and sign in
2. Click **Add New** → **Project**
3. Under "Import Git Repository", click **Import** next to `space3pl-nexus`
   - If you don't see it, click **Adjust GitHub App Permissions** and give Vercel access to the repo
4. On the configuration screen:
   - **Framework Preset:** Leave as "Other" (it's a static site)
   - **Root Directory:** Leave as `.` (default)
   - **Build Command:** Leave blank
   - **Output Directory:** Leave blank
5. Click **Deploy**
6. Wait about 30 seconds
7. ✅ Done! You will see a success screen with your live URL

---

## Step 5 — Verify Your Deployment

Visit these URLs to confirm everything works:

| Page           | URL |
|----------------|-----|
| Landing Page   | `https://space3pl-nexus.vercel.app` |
| Admin Panel    | `https://space3pl-nexus.vercel.app/admin` |
| WMS App        | `https://space3pl-nexus.vercel.app/wms` |

Sign in to the Admin Panel with:
- **Email:** `admin@space3pl.com`
- **Password:** `Space3PL@2026`

---

## Step 6 — Custom Domain (Optional)

To use your own domain (e.g. `app.space3pl.com`):

1. Vercel Dashboard → your project → **Settings** → **Domains**
2. Click **Add Domain**
3. Enter your domain (e.g. `nexus.space3pl.com`)
4. Follow the DNS instructions shown (add a CNAME record pointing to `cns.vercel-dns.com`)
5. Wait for DNS propagation (5 minutes to 24 hours)

---

## Auto-Deploy After Changes

Once connected, **every push to the `main` branch automatically triggers a new deployment**.

To update the apps:

```bash
# Edit your files locally
# Then push to GitHub:
git add -A
git commit -m "Update: describe what changed"
git push
```

Vercel detects the push and re-deploys in about 30 seconds. No manual steps required.

---

## Protecting the App (Optional)

By default, your Vercel URL is publicly accessible. To restrict access:

**Option A — Vercel Password Protection** (easiest):
1. Vercel Dashboard → Project → **Settings** → **Deployment Protection**
2. Enable **Password Protection**
3. Set a password — visitors must enter it to access any page

**Option B — Restore the login screen:**
Use `admin/index.html` (the version with the login form) instead of `admin/index-no-login.html`. The login screen requires valid Supabase Auth credentials.

---

## Troubleshooting

**"Page not found" on `/admin` or `/wms`**
→ Check that `vercel.json` is in the root of the repository and was pushed correctly.

**App loads but shows connection error**
→ Check that your Supabase project is not paused. Go to supabase.com → your project → it should say "Active". If paused, click "Restore project".

**Can't sign in**
→ Confirm the schema.sql was run successfully. Check Supabase → Authentication → Users — you should see `admin@space3pl.com` listed.

**Changes not appearing after push**
→ Go to Vercel Dashboard → Deployments — confirm the latest deployment completed successfully.

---

*Space3PL NEXUS Deployment Guide — v2.0 — 2026*
