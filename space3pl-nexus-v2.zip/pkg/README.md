# Space3PL NEXUS — Warehouse Management Platform

> Full-stack warehouse management system for **Space3PL Oman** — serving non-food, non-oil SME clients in fashion, electronics, beauty, home goods and gifting.

---

## 📦 What's in This Repository

```
space3pl-nexus/
├── index.html                  # Landing page (links to both apps)
├── admin/
│   ├── index.html              # NEXUS Admin Panel (with login)
│   └── index-no-login.html     # Admin Panel (no login — auto-connects)
├── wms/
│   └── index.html              # WMS Mobile App (staff handheld)
├── supabase/
│   └── schema.sql              # Complete database schema — run once in Supabase SQL Editor
├── docs/
│   ├── DEPLOYMENT.md           # Step-by-step Vercel deployment guide
│   ├── USER_GUIDE.md           # How to use the Admin Panel
│   └── WMS_GUIDE.md            # How to use the WMS Mobile App
├── vercel.json                 # Vercel routing + security headers
├── package.json
├── .gitignore
└── README.md                   # This file
```

---

## 🏗️ Architecture

```
GitHub (source) ──► Vercel (hosting) ──► Browser
                                           │
                              Supabase JS SDK v2
                                           │
                              Supabase (eqmjdojaqzaakmbcsakc)
                              ├── PostgreSQL (75+ tables)
                              ├── Auth (email + password)
                              ├── Row Level Security (RLS)
                              └── Realtime
```

### Tech Stack

| Layer       | Technology                              |
|-------------|-----------------------------------------|
| Frontend    | Vanilla HTML / CSS / JavaScript         |
| Database    | Supabase PostgreSQL                     |
| Auth        | Supabase Auth (email + WMS PIN)         |
| SDK         | Supabase JS SDK v2 + REST API fallback  |
| Charts      | Chart.js 4.4                            |
| Hosting     | Vercel (static deployment)              |
| CI/CD       | GitHub → Vercel (auto-deploy on push)   |

---

## 🖥️ Applications

### 1. NEXUS Admin Panel (`/admin`)
Desktop and tablet enterprise dashboard for managers and supervisors.

| Module              | Features |
|---------------------|----------|
| **Dashboard**        | Live KPIs, inbound snapshot, picklist status, putaway queue |
| **Inbound Receipts** | Create POs, receive items line by line, discrepancy tracking, putaway creation |
| **Picklist Generator** | Single / Batch / Zone picking, auto-generate, assign to pickers, print/send to WMS |
| **Putaway Queue**    | Zone occupancy, bin assignment, auto-assign staff |
| **Zones & Bins**     | View warehouse zones and bin configuration |
| **Cycle Counts**     | Schedule, assign, track variances per zone |
| **Stock on Hand**    | Real-time SOH from `v_inventory_soh` view |
| **Movements**        | Full inventory movement audit trail |
| **Orders**           | Order management using your existing status_types table |
| **Clients**          | Full client profiles — contacts, integration flags, contracts, custom fields |
| **Client Services**  | Service catalog + per-client pricing |
| **User Management**  | Create staff, assign roles, granular permissions, WMS PIN |
| **Settings → Platforms** | Sales channel integrations, automation rules, status mapping |

### 2. WMS Mobile App (`/wms`)
Mobile-first app for warehouse staff — works on any smartphone or handheld scanner.

| Screen         | Features |
|----------------|----------|
| **Login**      | Email + password OR Employee ID + PIN |
| **Dashboard**  | My tasks, KPIs filtered to logged-in user |
| **Picking**    | Load picklists, mark items picked, sort by bin path |
| **Packing**    | Box selection, weight, fragile labels, save packing record |
| **Receiving**  | Scan PO, receive line by line, record discrepancies |
| **Putaway**    | Guided bin-by-bin putaway with confirmation |
| **Cycle Count**| Count items, automatic variance reporting |
| **Stock Lookup** | Live search by SKU / name / bin code |

---

## 🗄️ Database

**Supabase Project:** `eqmjdojaqzaakmbcsakc`
**Region:** EU West 2 (London)
**URL:** `https://eqmjdojaqzaakmbcsakc.supabase.co`

### Key Tables

| Table                  | Purpose |
|------------------------|---------|
| `profiles`             | Staff — linked to Supabase Auth, holds role + PIN + permissions |
| `organization`         | Clients — full profile, contract, custom fields |
| `client_contacts`      | Multiple contacts per client |
| `organization_platform`| Per-client sales channel integrations + API credentials |
| `platform_types`       | Master list of platform types (Shopify, Noon, etc.) |
| `organization_services`| Per-client service pricing |
| `service`              | Master service catalog |
| `orders`               | Orders — linked to `organization_platform` for automation |
| `inbound_receipts`     | GRN / Purchase Orders |
| `inbound_receipt_lines`| Per-SKU receiving lines |
| `picklists`            | Pick batches |
| `picklist_items`       | Individual pick lines with bin location |
| `putaway_tasks`        | Post-receiving putaway queue |
| `packing_records`      | Pack confirmation per order |
| `cycle_counts`         | Scheduled stock counts |
| `inventory_levels`     | SOH per product per bin |
| `inventory_movements`  | Full audit log |
| `status_types`         | Order/payment/fulfillment status lookup |

### Views

| View                | Purpose |
|---------------------|---------|
| `v_inventory_soh`   | SOH joined with product + bin + zone |
| `v_orders_summary`  | Orders with client name and platform name |
| `v_putaway_queue`   | Active putaway tasks with product + bin details |

### RLS Role Hierarchy

| Role          | Access Level |
|---------------|-------------|
| `super_admin` | Full access including DELETE |
| `admin`       | Full access excluding DELETE |
| `manager`     | Manage operations, view reports, manage clients |
| `warehouse`   | Inventory, inbound, putaway, cycle counts |
| `logistics`   | Orders, dispatch, deliveries |
| `finance`     | Invoices, reports, billing |
| `picker`      | View and complete own picklists |
| `packer`      | View orders, confirm packing |
| `receiver`    | Process inbound receipts |

---

## 🚀 Deployment

See **`docs/DEPLOYMENT.md`** for the full step-by-step guide.

### Quick Start

```bash
# 1. Push to GitHub
git init
git add -A
git commit -m "Initial deployment"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/space3pl-nexus.git
git push -u origin main

# 2. Deploy to Vercel
# Go to vercel.com/new → Import → space3pl-nexus → Deploy
# That's it — Vercel auto-deploys on every git push after this.
```

### Live URLs (after deployment)

| App               | URL |
|-------------------|-----|
| Landing Page      | `https://space3pl-nexus.vercel.app` |
| Admin Panel       | `https://space3pl-nexus.vercel.app/admin` |
| WMS Mobile App    | `https://space3pl-nexus.vercel.app/wms` |

---

## 🔐 Default Admin Credentials

| Field        | Value |
|--------------|-------|
| Email        | `admin@space3pl.com` |
| Password     | `Space3PL@2026` |
| Employee ID  | `EMP-001` |
| WMS PIN      | `1234` |
| Role         | Super Admin |

> ⚠️ **Change the password after first login.** Go to Supabase → Authentication → Users → click the user → Update Password.

---

## 🔌 Integration & Automation Flow

```
1. CLIENT ONBOARDING
   Admin Panel → Clients → New Client
   Admin Panel → Settings → Platforms → Add Integration
   (Enter API key, webhook URL, enable auto-fulfill)

2. ORDER SYNC (incoming)
   Platform sends order via webhook
   → NEXUS receives → creates order record
   → Links to client via organization_platform.id
   → Order appears in Admin Panel + WMS picking queue

3. FULFILLMENT
   WMS App → Picking → Packing → Admin dispatches
   → Order status updated to Dispatched

4. AUTO-FULFILL CALLBACK (outgoing, when enabled)
   On dispatch → NEXUS calls platform API
   → Pushes fulfillment status + tracking number back
   → Platform marks order as fulfilled for the customer

5. INVENTORY SYNC (when enabled)
   After every stock change → NEXUS pushes
   updated available quantity to platform
   → Prevents overselling
```

---

## 👤 Creating New Staff Users

**Via Admin Panel (recommended):**
1. Sign in → User Management → `+ Create User`
2. Fill Info tab (name, employee ID, department, shift)
3. Fill Role & Permissions tab (select role, adjust permissions)
4. Fill Login Access tab (email, password, WMS PIN)
5. Click **Save User**

**Via Supabase Dashboard (backup method):**
1. Supabase → Authentication → Users → Add User
2. Copy the new user's UUID
3. Table Editor → `profiles` → Insert row with UUID, full_name, role, employee_id, pin

---

## 📁 File Versions Explained

| File                          | Use Case |
|-------------------------------|----------|
| `admin/index.html`            | Production — requires login (recommended) |
| `admin/index-no-login.html`   | Internal/demo — auto-connects, no login screen |
| `wms/index.html`              | Always requires Employee ID + PIN or email login |

---

*Space3PL Oman — Built with Supabase + Vercel — 2026*
